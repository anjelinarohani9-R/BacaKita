-- Jalankan di Supabase Dashboard > SQL Editor.
-- Buat bucket "books" melalui Storage dengan Public bucket = ON.
-- Gunakan buku yang memang legal untuk didistribusikan.

create extension if not exists pgcrypto;

create table if not exists public.books (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  author text,
  category text not null,
  description text,
  cover_url text,
  epub_path text not null,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.books enable row level security;
alter table public.admin_users enable row level security;

create or replace function public.is_bacakita_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.admin_users
    where user_id = (select auth.uid())
  );
$$;

grant execute on function public.is_bacakita_admin() to anon, authenticated;

drop policy if exists "Published books are visible" on public.books;
create policy "Published books are visible" on public.books
for select to anon, authenticated using (published = true or public.is_bacakita_admin());

drop policy if exists "Admins insert books" on public.books;
create policy "Admins insert books" on public.books
for insert to authenticated with check (public.is_bacakita_admin());

drop policy if exists "Admins update books" on public.books;
create policy "Admins update books" on public.books
for update to authenticated using (public.is_bacakita_admin()) with check (public.is_bacakita_admin());

drop policy if exists "Admins delete books" on public.books;
create policy "Admins delete books" on public.books
for delete to authenticated using (public.is_bacakita_admin());

drop policy if exists "Admin reads own admin row" on public.admin_users;
create policy "Admin reads own admin row" on public.admin_users
for select to authenticated using (user_id = (select auth.uid()));

-- Jalankan setelah bucket books dibuat di Storage.
drop policy if exists "Public can read book files" on storage.objects;
create policy "Public can read book files" on storage.objects
for select to anon, authenticated using (bucket_id = 'books');

drop policy if exists "Admins upload book files" on storage.objects;
create policy "Admins upload book files" on storage.objects
for insert to authenticated with check (bucket_id = 'books' and public.is_bacakita_admin());

drop policy if exists "Admins update book files" on storage.objects;
create policy "Admins update book files" on storage.objects
for update to authenticated using (bucket_id = 'books' and public.is_bacakita_admin())
with check (bucket_id = 'books' and public.is_bacakita_admin());

drop policy if exists "Admins delete book files" on storage.objects;
create policy "Admins delete book files" on storage.objects
for delete to authenticated using (bucket_id = 'books' and public.is_bacakita_admin());

-- Setelah membuat akun admin di Authentication > Users, masukkan UUID akun:
-- insert into public.admin_users (user_id) values ('UUID-AKUN-ADMIN');
