document.addEventListener("DOMContentLoaded",async()=>{
 const list=document.getElementById("bookList"),search=document.getElementById("searchInput"),filter=document.getElementById("categoryFilter"),count=document.getElementById("bookCount");
 filter.value=new URLSearchParams(location.search).get("category")||"";
 let books=[];try{books=await BacaKita.getBooks()}catch(e){BacaKita.showError(list,e);return}
 function render(){let q=search.value.trim().toLowerCase(),cat=filter.value;let result=books.filter(b=>(!cat||b.category===cat)&&(!q||`${b.title} ${b.author||""}`.toLowerCase().includes(q)));count.textContent=`${result.length} buku ditemukan`;list.innerHTML=result.length?result.map(BacaKita.bookCard).join(""):'<div class="empty-state">Buku yang kamu cari belum tersedia.</div>'}
 search.addEventListener("input",render);filter.addEventListener("change",render);render();
});