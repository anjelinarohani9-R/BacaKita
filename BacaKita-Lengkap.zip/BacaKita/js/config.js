/* Isi dengan Project URL dan anon/publishable key dari Supabase.
   Jangan pernah memasukkan service_role key ke file frontend. */
window.BACAKITA_CONFIG = {
  SUPABASE_URL: "MASUKKAN_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "MASUKKAN_SUPABASE_ANON_KEY",
  STORAGE_BUCKET: "books"
};
window.BACAKITA_CATEGORIES = ["Novel","Pendidikan","Sastra","Teknologi","Psikologi","Pengembangan Diri"];
