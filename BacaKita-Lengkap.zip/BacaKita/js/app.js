(function(){
"use strict";
const KEYS={favorites:"bk_favorites",history:"bk_history",progress:"bk_progress",bookmarks:"bk_bookmarks"};
function read(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}}
function write(key,value){localStorage.setItem(key,JSON.stringify(value))}
function esc(value=""){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
const config=window.BACAKITA_CONFIG||{};
let client=null;
function init(){
 if(client)return true;
 if(!window.supabase?.createClient||!config.SUPABASE_URL||config.SUPABASE_URL.includes("MASUKKAN")||!config.SUPABASE_ANON_KEY||config.SUPABASE_ANON_KEY.includes("MASUKKAN"))return false;
 client=window.supabase.createClient(config.SUPABASE_URL,config.SUPABASE_ANON_KEY);
 return true;
}
async function getBooks(){
 if(!init())throw new Error("Supabase belum dikonfigurasi. Isi js/config.js terlebih dahulu.");
 const {data,error}=await client.from("books").select("*").eq("published",true).order("created_at",{ascending:false});
 if(error)throw error;return data||[];
}
async function getAllBooks(){
 if(!init())throw new Error("Supabase belum dikonfigurasi.");
 const {data,error}=await client.from("books").select("*").order("created_at",{ascending:false});
 if(error)throw error;return data||[];
}
async function getBook(id){
 if(!init())throw new Error("Supabase belum dikonfigurasi.");
 const {data,error}=await client.from("books").select("*").eq("id",id).single();
 if(error)throw error;return data;
}
function favoriteIds(){return read(KEYS.favorites,[])}
function isFavorite(id){return favoriteIds().includes(String(id))}
function toggleFavorite(id){id=String(id);let a=favoriteIds();a=a.includes(id)?a.filter(x=>x!==id):[...a,id];write(KEYS.favorites,a);return a.includes(id)}
function history(){return read(KEYS.history,[])}
function saveHistory(book,progress=0){let a=history().filter(x=>x.id!==book.id);a.unshift({id:book.id,title:book.title,author:book.author,cover_url:book.cover_url||"",progress,updated_at:new Date().toISOString()});write(KEYS.history,a.slice(0,100))}
function saveProgress(id,cfi,percent){let p=read(KEYS.progress,{});p[id]={cfi,percent,updated_at:new Date().toISOString()};write(KEYS.progress,p)}
function getProgress(id){return read(KEYS.progress,{})[id]||null}
function saveBookmark(id,cfi,label){let all=read(KEYS.bookmarks,{});all[id]=all[id]||[];if(!all[id].some(x=>x.cfi===cfi))all[id].push({cfi,label:label||"Penanda",created_at:new Date().toISOString()});write(KEYS.bookmarks,all)}
function getBookmarks(id){return read(KEYS.bookmarks,{})[id]||[]}
function removeBookmark(id,cfi){let all=read(KEYS.bookmarks,{});all[id]=(all[id]||[]).filter(x=>x.cfi!==cfi);write(KEYS.bookmarks,all)}
function coverHTML(book){return `<div class="book-cover">${book.cover_url?`<img loading="lazy" src="${esc(book.cover_url)}" alt="Sampul ${esc(book.title)}">`:`<span>${esc(book.title||"BacaKita")}</span>`}</div>`}
function bookCard(book){return `<article class="book-card">${coverHTML(book)}<div class="book-info"><h3>${esc(book.title)}</h3><p>${esc(book.author||"Penulis tidak dicantumkan")}</p><span class="category-tag">${esc(book.category||"Umum")}</span><p style="margin-top:13px"><a class="text-link" href="./detail.html?id=${encodeURIComponent(book.id)}">Lihat buku →</a></p></div></article>`}
function showError(container,error){if(container)container.innerHTML=`<div class="empty-state">${esc(error.message||"Terjadi kesalahan. Coba lagi nanti.")}</div>`}
window.BacaKita={init,get client(){init();return client},getBooks,getAllBooks,getBook,favoriteIds,isFavorite,toggleFavorite,history,saveHistory,saveProgress,getProgress,saveBookmark,getBookmarks,removeBookmark,coverHTML,bookCard,esc,showError,read,write,KEYS};
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelector(".menu-toggle")?.addEventListener("click",()=>document.querySelector(".main-nav")?.classList.toggle("open"));
 const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
 if("serviceWorker" in navigator && location.protocol==="https:")navigator.serviceWorker.register("./service-worker.js").catch(console.warn);
 const featured=document.getElementById("featuredBooks");
 if(featured){getBooks().then(books=>{featured.innerHTML=books.length?books.slice(0,4).map(bookCard).join(""):'<div class="empty-state">Belum ada buku yang diterbitkan.</div>'}).catch(e=>showError(featured,e))}
});
})();