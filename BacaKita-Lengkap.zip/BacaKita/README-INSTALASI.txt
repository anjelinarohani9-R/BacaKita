BACAKITA — PANDUAN PEMASANGAN
==============================

1. UNDUH DAN UNZIP
- Ekstrak folder BacaKita.
- Unggah seluruh isi folder ke root repository GitHub bernama BacaKita.
- Pertahankan struktur folder (css, js, admin, assets).

2. SIAPKAN SUPABASE
- Buat project di Supabase.
- Buka SQL Editor, jalankan isi supabase-setup.sql.
- Buka Storage, buat bucket bernama: books
- Aktifkan Public bucket agar pembaca dapat membaca EPUB yang memang boleh dibagikan secara publik.
- Authentication > Providers: aktifkan Email.
- Authentication > Users: buat akun admin.
- Salin UUID akun admin, lalu jalankan:
  insert into public.admin_users (user_id) values ('UUID-AKUN-ADMIN');
- Project Settings > API: salin Project URL dan anon/public key.
- Masukkan keduanya ke js/config.js. Jangan gunakan service_role key.

3. TERBITKAN WEBSITE
- GitHub repository > Settings > Pages.
- Build and deployment: Deploy from a branch.
- Branch: main, folder: /(root), lalu Save.
- Tunggu proses publikasi dan buka URL GitHub Pages.

4. TAMBAHKAN BUKU
- Buka /admin/login.html pada alamat website.
- Login dengan akun admin yang UUID-nya sudah didaftarkan.
- Isi informasi buku, pilih file EPUB, lalu simpan.
- Gunakan hanya buku domain publik, berlisensi terbuka, atau yang kamu punya izin untuk didistribusikan.

5. FITUR OFFLINE
- Buka website ketika online, lalu kunjungi halaman Offline.
- Tekan Unduh semua buku.
- Tunggu proses selesai sebelum memutus koneksi internet.
- Browser membatasi ruang penyimpanan dan dapat menghapus data situs. Jadi unduhan offline tidak dijamin permanen di semua perangkat.
- Pembaca EPUB dan file buku harus sudah tersimpan agar dapat digunakan offline.

CATATAN PENTING
- GitHub Pages hanya meng-host file website statis; Supabase menyediakan database, autentikasi, dan penyimpanan EPUB.
- File EPUB disediakan admin, bukan diunggah oleh pengunjung.
- Jika CDN atau font eksternal belum pernah tersimpan, akses pertama perlu internet.
- Service Worker dan PWA membutuhkan HTTPS (GitHub Pages sudah menggunakan HTTPS).
- Uji dahulu dengan beberapa EPUB legal yang ukurannya kecil.
- Jangan memasukkan password admin atau service_role key ke kode frontend.
